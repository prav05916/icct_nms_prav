<?php
/** Personal widget layouts; only known widgets, at most five dashboards. */
function icct_nms_dashboard_validate($value) {
    if(!is_array($value)||!isset($value['dashboards'],$value['selected'])||!is_array($value['dashboards'])||count($value['dashboards'])<1||count($value['dashboards'])>5)throw new InvalidArgumentException('Choose one to five dashboards.');
    $clean=['selected'=>(int)$value['selected'],'dashboards'=>[],'site_scope'=>'native'];
    foreach(array_values($value['dashboards']) as $index=>$dashboard){
        if(!is_array($dashboard)||!isset($dashboard['widgets'])||!is_array($dashboard['widgets'])||count($dashboard['widgets'])>9)throw new InvalidArgumentException('Invalid dashboard widgets.');
        $widgets=array_values($dashboard['widgets']);
        foreach($widgets as $widget)if(!is_string($widget))throw new InvalidArgumentException('Invalid widget.');
        if(count(array_unique($widgets))!==count($widgets)||array_diff($widgets,['topology','birds','alarms','ack','escalation','frequent','recent','ports','problematic']))throw new InvalidArgumentException('Unknown or duplicate widget.');
        $name=$dashboard['name'] ?? 'Dashboard #'.($index+1);
        if(!is_string($name)||trim($name)===''||mb_strlen(trim($name))>60)throw new InvalidArgumentException('Enter a dashboard name of 1 to 60 characters.');
        $columns=$dashboard['columns'] ?? 'auto';
        if(!in_array($columns,['auto',2,3],true))throw new InvalidArgumentException('Choose automatic, two or three columns.');
        $siteId=$dashboard['site_id'] ?? 0;
        if(!is_int($siteId)||$siteId<0||$siteId>4294967295)throw new InvalidArgumentException('Choose a valid site.');
        $clean['dashboards'][]=['name'=>trim($name),'columns'=>$columns,'site_id'=>$siteId,'widgets'=>array_merge(['topology'],array_values(array_diff($widgets,['topology'])))];
    }
    if($clean['selected']<0||$clean['selected']>=count($clean['dashboards']))throw new InvalidArgumentException('Dashboard unavailable.');
    if(isset($value['deleted'])){
        $deleted=$value['deleted'];
        if(!is_array($deleted)||!isset($deleted['index'],$deleted['dashboard'])||!is_int($deleted['index'])||$deleted['index']<0||$deleted['index']>4)throw new InvalidArgumentException('Invalid deleted dashboard.');
        $restored=icct_nms_dashboard_validate(['selected'=>0,'dashboards'=>[$deleted['dashboard']]]);
        $clean['deleted']=['index'=>$deleted['index'],'dashboard'=>$restored['dashboards'][0]];
    }
    return $clean;
}
function icct_nms_dashboard_preferences() {
    $raw=db_fetch_cell_prepared('SELECT meta_value FROM plugin_icct_nms_meta WHERE meta_key=?',['dashboard_user_'.icct_backend_current_user_id()]);
    try{if($raw){$value=json_decode($raw,true,512,JSON_THROW_ON_ERROR);icct_nms_dashboard_validate($value);return icct_nms_dashboard_validate($value);}}catch(Throwable $e){}
    return ['selected'=>0,'dashboards'=>[['widgets'=>['topology','birds','alarms','ack','escalation','frequent','recent','ports','problematic']]]];
}
function icct_nms_dashboard_save($value) {
    $clean=icct_nms_dashboard_validate($value);
    icct_backend_category_execute('INSERT INTO plugin_icct_nms_meta(meta_key,meta_value,updated_at) VALUES(?,?,NOW()) ON DUPLICATE KEY UPDATE meta_value=VALUES(meta_value),updated_at=NOW()',['dashboard_user_'.icct_backend_current_user_id(),json_encode($clean,JSON_THROW_ON_ERROR)]);
    return $clean;
}
function icct_nms_dashboard_readings($mapData) {
    $severities=array_fill_keys(['Critical','Major','Minor','Warning','Information'],0);$segments=[];
    $devices=$mapData['unlocated'];$sites=[];$frequent=[];$recent=[];$ports=[];$problematic=[];
    foreach($mapData['sites'] as $site){$devices=array_merge($devices,$site['devices']);$summary=icct_nms_map_site_summary($site);$sites[]=['id'=>$site['id'],'name'=>$site['name'],'coordinates'=>$site['coordinates'],'status'=>$summary['status']];}
    foreach($devices as $device){if(!empty($device['ports']['items']))$ports[]=['id'=>$device['id'],'name'=>$device['name'],'ports'=>$device['ports']];foreach($device['fault_alarms'] ?? [] as $alarm){$recent[]=$alarm+['device'=>$device['name'] ?? 'Device','device_id'=>(int)($device['id'] ?? 0)];$key=json_encode([$alarm['name'],$alarm['severity']]);if(!isset($frequent[$key]))$frequent[$key]=$alarm+['count'=>0];$frequent[$key]['count']++;}$total=0;foreach($device['fault_counts']??[] as $key=>$count){if(isset($severities[$key])){$severities[$key]+=(int)$count;$total+=(int)$count;}}$segment=trim($device['category']??'')?:'Unassigned';$segments[$segment]=($segments[$segment]??0)+$total;}
    foreach($devices as $device){
        $counts=array_intersect_key($device['fault_counts'] ?? [],$severities);
        if(array_sum($counts)>0)$problematic[]=['id'=>(int)($device['id'] ?? 0),'name'=>$device['name'] ?? 'Device','counts'=>$counts];
    }
    arsort($segments);
    $frequent=array_values($frequent);usort($frequent,static fn($a,$b)=>($b['count']<=>$a['count']) ?: strcmp($a['name'],$b['name']) ?: strcmp($a['severity'],$b['severity']));
    usort($recent,static fn($a,$b)=>(($b['time'] ?? 0)<=>($a['time'] ?? 0)) ?: strcmp($a['name'],$b['name']));
    $total=array_sum($severities);
    $unknown=$total>0?null:0;
    usort($ports,static fn($a,$b)=>strnatcasecmp($a['name'],$b['name']));
    return ['device_alarms'=>array_map(static fn($device)=>['id'=>(int)($device['id']??0),'counts'=>$device['fault_counts']??[],'alarm'=>$device['alarm']??null],$devices),'problematic'=>['total_devices'=>count($devices),'devices'=>$problematic],'ports'=>$ports,'recent'=>array_slice($recent,0,25),'frequent'=>array_slice($frequent,0,10),'ack'=>['Ack'=>$unknown,'Not_Ack'=>$unknown],'escalation'=>['Esc'=>$unknown,'Not_Esc'=>$unknown],'sites'=>$sites,'severity'=>$severities,'segments'=>$segments,'total'=>array_sum($severities),'updated'=>date(DATE_ATOM)];
}

/** Resolve the server by the native poller identity, never an arbitrary demo site. */
function icct_nms_dashboard_server_center($hosts, $poller) {
    $hostname=strtolower(trim($poller['hostname'] ?? ''));
    $matches=array_values(array_filter($hosts,static function($host)use($hostname){
        return $hostname!=='' && (strtolower(trim($host['hostname'] ?? ''))===$hostname || strtolower(trim($host['snmp_sysName'] ?? ''))===$hostname);
    }));
    $center=['name'=>$poller['name'] ?? 'Cacti server','status'=>'Unknown','device_id'=>null,'site_id'=>null,'coordinates'=>null];
    if(count($matches)!==1)return $center;
    $host=$matches[0];
    return array_replace($center,['name'=>$host['description'],'device_id'=>(int)$host['id'],'site_id'=>(int)$host['site_id'],'status'=>['Up'=>'Online','Down'=>'Offline','Disabled'=>'Disabled'][$host['status_label']] ?? 'Unknown']);
}
function icct_nms_dashboard_server() {
    global $config;
    $poller=db_fetch_row_prepared('SELECT name,hostname FROM poller WHERE id=?',[(int)($config['poller_id'] ?? 1)]);
    $center=icct_nms_dashboard_server_center(icct_nms_inventory(),$poller ?: []);
    if($center['site_id']){
        $site=db_fetch_row_prepared('SELECT latitude,longitude FROM sites WHERE id=?',[$center['site_id']]);
        $center['coordinates']=icct_nms_map_coordinates($site['latitude'] ?? null,$site['longitude'] ?? null);
    }
    return $center;
}

/** Site choices come from the native site catalogue. */
function icct_nms_dashboard_sites($map){
    return array_map(static fn($site)=>['id'=>(int)$site['id'],'name'=>$site['name']],db_fetch_assoc('SELECT id,name FROM sites ORDER BY name,id'));
}
function icct_nms_dashboard_scope($map,$siteId){
    if($siteId===0)return $map;
    if(!in_array($siteId,array_column(icct_nms_dashboard_sites($map),'id'),true))throw new RuntimeException('Site unavailable.');
    $map['sites']=array_values(array_filter($map['sites'],static fn($site)=>(int)$site['id']===$siteId));
    $map['unlocated']=array_values(array_filter($map['unlocated'],static fn($device)=>(int)$device['site_id']===$siteId));
    return icct_nms_dashboard_recount($map);
}
function icct_nms_dashboard_recount($map){
    $devices=$map['unlocated'];foreach($map['sites'] as $site)$devices=array_merge($devices,$site['devices']);
    $map['counts']=['total'=>count($devices),'online'=>0,'offline'=>0,'disabled'=>0,'other'=>0];
    foreach($devices as $device)$map['counts'][$device['status']==='Up'?'online':($device['status']==='Down'?'offline':($device['status']==='Disabled'?'disabled':'other'))]++;
    return $map;
}
