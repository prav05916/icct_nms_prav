<?php
require_once __DIR__ . '/../../presets/services/device_type_service.php';
require_once __DIR__ . '/../../presets/services/rack_preset_service.php';
require_once __DIR__ . '/../../dashboard/rack-view/services/rack_view_service.php';
require_once __DIR__ . '/../../configuration/services/configuration_history.php';

/**
 * Device and SNMP writes using Cacti field definitions and existing NMS services.
 */

/**
 * Validate submitted Basic Information before saving core data and related metadata.
 */
function icct_nms_save_device($id, $old, $input)
{
    global $fields_host_edit;
    foreach (
        [
            'short_name',
            'serial_number',
            'mac_address',
            'chassis_id',
            'rack_unit_count',
            'category_id',
            'device_type',
            'rack_id',
            'rack_position',
            'cross_launch_url'
        ]
        as $field
    ) {
        if (!array_key_exists($field, $input) || !is_scalar($input[$field])) {
            throw new InvalidArgumentException('Missing field: ' . $field);
        }
    }
    $values = icct_nms_native_values($old, $input, [
        'description',
        'hostname',
        'host_template_id',
        'site_id',
        'poller_id',
        'device_threads',
        'notes'
    ]);
    $values['disabled'] = isset($input['enabled']) ? '' : 'on';
    $short = icct_backend_short_name_validate($input['short_name'] ?? '');
    if ($short === '') {
        $short = icct_backend_short_name_generate($values['description'], $input['device_type'], $id);
    }
    // Displayed collector evidence is not silently promoted to a manual override.
    $observed = $id ? icct_backend_identity_observed($old) : [];
    $manual = $id ? db_fetch_row_prepared('SELECT serial_number,mac_address,chassis_id FROM plugin_icct_nms_device_metadata WHERE host_id=?', [$id]) : [];
    foreach (['serial_number', 'mac_address', 'chassis_id'] as $field) {
        if (empty($manual[$field]) && isset($observed[$field]) && ($input[$field] ?? '') === $observed[$field]) $input[$field] = '';
    }
    $serial = icct_backend_manual_serial_validate($input['serial_number'] ?? '');
    $identity = icct_backend_identity_manual_validate([
        'manual_mac_address' => $input['mac_address'] ?? '',
        'manual_chassis_id' => $input['chassis_id'] ?? ''
    ]);
    $category = icct_backend_topology_integer($input['category_id'] ?? '', 0, 2147483647, 'Segment');
    if ($category && !icct_backend_category_exists($category)) {
        throw new InvalidArgumentException('Select a saved segment.');
    }
    // Only a saved profile in the selected segment can be assigned.
    $type = icct_nms_resolve_device_type($category, $input['device_type']);
    $url = icct_backend_config_text($input['cross_launch_url'] ?? '', 2048, 'Cross Launch URL', false);
    if (
        $url !== '' &&
        (!filter_var($url, FILTER_VALIDATE_URL) ||
            !in_array(strtolower(parse_url($url, PHP_URL_SCHEME)), ['http', 'https'], true))
    ) {
        throw new InvalidArgumentException('Cross Launch URL must use HTTP or HTTPS.');
    }
    if (array_key_exists('rack_units',$input)) {
        if (!empty($input['rack_peripheral'])) $input['rack_position']='peripheral';
        elseif ($input['rack_units']) {
            [$start,$height]=icct_nms_rack_units($input['rack_units'],100);
            if ($height === 1 && !empty($input['rack_unit_count'])) {
                $rawCount = $input['rack_unit_count'];
                if (is_string($rawCount) && preg_match('/^([0-9]+)/', trim($rawCount), $matches)) {
                    $rawCount = (int)$matches[1];
                }
                $requestedUnits = (int)$rawCount;
                if ($requestedUnits > 1 && $requestedUnits <= 42) {
                    $height = $requestedUnits;
                }
            }
            $input['rack_position']=$start.':'.$height;
        }
        else $input['rack_position']='';
    }
    $rackSelection=$input['rack_id'];
    $rack = is_string($rackSelection) && str_starts_with($rackSelection,'preset:')
        ? icct_nms_resolve_preset_rack($rackSelection,(int)$values['site_id'],$input['rack_position'])
        : icct_backend_topology_integer($rackSelection,0,2147483647,'Rack');
    $placement = null;
    $peripheral=$input['rack_position']==='peripheral';
    if ($rack && !$peripheral) {
        $r = db_fetch_row_prepared(
            'SELECT r.* FROM plugin_icct_nms_racks r WHERE r.id=?',
            [$rack]
        );
        if (!$r || ((int) $r['site_id'] !== 0 && (int) $r['site_id'] !== (int) $values['site_id'])) {
            throw new InvalidArgumentException('Select a saved rack at the device site.');
        }
        $position = explode(':', (string) ($input['rack_position'] ?? ''));
        if (count($position) !== 2) {
            throw new InvalidArgumentException('Select rack placement.');
        }
        $start = icct_backend_topology_integer($position[0], 1, 100, 'Rack unit');
        $height = icct_backend_topology_integer($position[1], 1, 100, 'Rack height');
        if ($start + $height - 1 > (int) $r['unit_count']) {
            throw new InvalidArgumentException('Placement exceeds rack capacity.');
        }
        if (
            db_fetch_cell_prepared(
                'SELECT host_id FROM plugin_icct_nms_rack_devices WHERE rack_id=? AND host_id<>? AND start_unit<=? AND start_unit+unit_height-1>=?',
                [$rack, $id, $start + $height - 1, $start]
            )
        ) {
            throw new InvalidArgumentException('Rack units are occupied.');
        }
        $placement = ['rack_id' => $rack, 'start_unit' => $start, 'unit_height' => $height];
    }
    if($id && !icct_nms_meta('configuration_latest_'.$id))icct_nms_configuration_record($id,'Initial baseline');
    $saved = icct_backend_device_save($id, $values);
    try {
        $classification = $id
            ? db_fetch_row_prepared(
                'SELECT device_role FROM plugin_icct_nms_device_classification WHERE host_id=?',
                [$id]
            )
            : [];
        icct_backend_device_classification_save(
            $saved,
            $category,
            $type,
            $classification['device_role'] ?? ''
        );
        icct_backend_short_name_save($saved, $short);
        icct_backend_manual_serial_save($saved, $serial);
        icct_backend_identity_manual_save($saved, $identity);
        $rawUnitCount = $input['rack_unit_count'] ?? 1;
        if (is_string($rawUnitCount) && preg_match('/^([0-9]+)/', trim($rawUnitCount), $matches)) {
            $rawUnitCount = (int)$matches[1];
        }
        $rackUnitCount = icct_backend_topology_integer($rawUnitCount, 1, 42, 'Rack Unit Count');
        icct_backend_category_execute('INSERT INTO plugin_icct_nms_device_metadata(host_id,rack_unit_count,updated_by,updated_at) VALUES(?,?,?,NOW()) ON DUPLICATE KEY UPDATE rack_unit_count=VALUES(rack_unit_count),updated_at=NOW()', [$saved, $rackUnitCount, icct_backend_current_user_id()]);
        icct_backend_category_execute(
            'INSERT INTO plugin_icct_nms_meta(meta_key,meta_value,updated_at) VALUES(?,?,NOW()) ON DUPLICATE KEY UPDATE meta_value=VALUES(meta_value),updated_at=NOW()',
            ['icct_cross_launch_' . $saved, $url]
        );
        $units=$placement ? range($placement['start_unit'],$placement['start_unit']+$placement['unit_height']-1) : [];
        icct_nms_rack_place($saved,(int)$values['site_id'],$rack,$units,$peripheral);
    } catch (Throwable $e) {
        throw new RuntimeException(
            'Device ' .
                $saved .
                ' was saved in Cacti, but metadata was not fully saved. Edit this ID; do not create a duplicate. ' .
                $e->getMessage(),
            0,
            $e
        );
    }
    icct_nms_configuration_record($saved, $id ? 'Basic Information saved' : 'Device created');
    require_once dirname(__DIR__, 2) . '/protocols/syslog/services/backend/syslog.php';
    try { icct_backend_syslog_collect_availability_events(); } catch (Throwable $e) {}
    return $saved;
}

/** Native ranges shared by validation and SNMP/availability controls. */
function icct_nms_native_ranges()
{
    return [
        'snmp_port' => [1, 65535],
        // Cacti host.snmp_timeout is an unsigned MEDIUMINT.
        'snmp_timeout' => [1, 16777215],
        'ping_timeout' => [1, 2147483647],
        'ping_retries' => [0, 2147483647]
    ];
}
function icct_nms_native_range_attributes($field)
{
    [$min,$max] = icct_nms_native_ranges()[$field];
    return 'required min="'.$min.'" max="'.$max.'"';
}

/**
 * Merge only submitted controls into native values, retaining blank credential replacements.
 */
function icct_nms_native_values($old, $input, $fields)
{
    global $fields_host_edit;
    $values = $old;
    foreach ($fields as $field) {
        if (!array_key_exists($field, $input) || !is_scalar($input[$field])) {
            throw new InvalidArgumentException('Missing field: ' . $field);
        }
        if (!isset($fields_host_edit[$field])) {
            throw new RuntimeException('Cacti form field is unavailable: ' . $field);
        }
        if (
            in_array($field, ['snmp_password', 'snmp_priv_passphrase'], true) &&
            $input[$field] === ''
        ) {
            continue;
        }
        $values[$field] = icct_backend_core_field_value($field, $fields_host_edit[$field], $input[$field]);
    }
    foreach (
        icct_nms_native_ranges()
        as $key => $range
    ) {
        if (!array_key_exists($key, $values)) {
            throw new RuntimeException('Required Cacti default is missing: ' . $key);
        }
        $values[$key] = icct_backend_topology_integer($values[$key], $range[0], $range[1], $key);
    }
    foreach (['snmp_engine_id', 'external_id', 'location', 'ping_port'] as $key) {
        if (!array_key_exists($key, $values)) {
            throw new RuntimeException('Required Cacti default is missing: ' . $key);
        }
    }
    return $values;
}

/**
 * Save supported SNMP fields without changing unshown device configuration.
 */
function icct_nms_save_snmp($id, $old, $input)
{
    // The UI omits disabled reachability controls. Keep their native values.
    $availability = (string)($input['availability_method'] ?? '');
    $hidden = !in_array($availability, ['1','3','4'], true) ? ['ping_method'] : [];
    if ($availability === '0') $hidden = array_merge($hidden, ['ping_timeout','ping_retries']);
    $v3 = (string)($input['snmp_version'] ?? '') === '3';
    $security = (string)($input['snmp_security_level'] ?? '');
    if (!$v3 || $security === 'noAuthNoPriv') $hidden = array_merge($hidden, ['snmp_auth_protocol','snmp_password']);
    if (!$v3 || in_array($security, ['noAuthNoPriv','authNoPriv'], true)) $hidden = array_merge($hidden, ['snmp_priv_protocol','snmp_priv_passphrase']);
    foreach ($hidden as $field) {
        if (!array_key_exists($field, $input) && array_key_exists($field, $old)) {
            $input[$field] = in_array($field, ['snmp_auth_protocol','snmp_priv_protocol'], true) && $old[$field] === '' ? '[None]' : $old[$field];
        }
    }
    foreach (['snmp_password' => 'snmp_password_confirm', 'snmp_priv_passphrase' => 'snmp_priv_confirm'] as $secret => $confirm) {
        if (isset($input[$confirm]) && ($input[$secret] ?? '') !== $input[$confirm]) {
            throw new InvalidArgumentException('SNMP replacement passphrases must match their confirmation.');
        }
    }
    if (isset($input['snmp_security_level'])) {
        if (!in_array($input['snmp_security_level'], ['noAuthNoPriv', 'authNoPriv', 'authPriv'], true)) {
            throw new InvalidArgumentException('Invalid SNMP security level.');
        }
        if ($input['snmp_security_level'] === 'noAuthNoPriv') $input['snmp_auth_protocol'] = '[None]';
        if ($input['snmp_security_level'] !== 'authPriv') $input['snmp_priv_protocol'] = '[None]';
    }
    $values = icct_nms_native_values($old, $input, [
        'snmp_version',
        'snmp_community',
        'snmp_port',
        'snmp_timeout',
        'max_oids',
        'availability_method',
        'ping_method',
        'ping_timeout',
        'ping_retries',
        'snmp_username',
        'snmp_auth_protocol',
        'snmp_priv_protocol',
        'snmp_context',
        'snmp_password',
        'snmp_priv_passphrase'
    ]);
    return icct_backend_device_save($id, $values);
}
