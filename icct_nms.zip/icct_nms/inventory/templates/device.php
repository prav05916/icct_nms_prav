<?php
/**
 * Basic Information form and saved observations. The controller supplies saved values.
 */
?>
<form method="post" class="device-form" id="device-form" <?= !empty($cloneId)
    ? 'data-clone="true"'
    : "" ?>>
    <?php icct_nms_token(); ?>
    <div class="titlebar">
        <h1><?= icct_nms_h($title) ?></h1>
        <div class="title-actions">
            <a class="button" href="inventory/controllers/inventory.php">Cancel</a>
            <?php if (!$readonly): ?>
            <button class="button primary" type="button" data-wizard-save><?= !empty($cloneId)
                ? "Create Clone"
                : "Save" ?></button>
            <?php endif; ?>
        </div>
    </div>
    <?php if (
        !empty($cloneId)
    ): ?><p class="clone-instructions">Enter a new hostname/IP address, then select Create Clone to add the device to Inventory.</p><?php endif; ?>
    <nav class="steps" aria-label="Device configuration">
        <ol>
            <li class="current">
                <span class="step-marker"></span>
                <span>
                    Basic Information
                    <small>1/7</small>
                </span>
            </li>
            <li>
                <a href="#protocol">
                    Protocol Config
                    <small>2/7</small>
                </a>
            </li>
            <li>
                <a href="#diagnostics">
                    Device Diagnostics
                    <small>3/7</small>
                </a>
            </li>
            <li <?= $id ? "" : 'aria-disabled="true"' ?>><a href="#graphs">Graphs<small>4/7</small></a></li>
            <li <?= $id ? "" : 'aria-disabled="true"' ?>><a href="#data-query">Data Query<small>5/7</small></a></li>
            <li><a href="#ports">Port Config<small>6/7</small></a></li>
            <li><a href="#fcaps">FCAPS<small>7/7</small></a></li>
        </ol>
    </nav>
    <fieldset class="device-fields" <?= $readonly ? "disabled" : "" ?>>
        <div class="enable-field">
            <span class="field-label">Enable/Disable Device</span>
            <label class="switch-label">
                <input class="switch-input" type="checkbox" name="enabled" <?= $values[
                    "enabled"
                ]
                    ? "checked"
                    : "" ?> />
                <span class="switch-track"></span>
                <span>Enable</span>
            </label>
        </div>
        <div class="form-grid">
            <?php
            icct_nms_input(
                "Device Name",
                "description",
                $values["description"],
                "text",
                "required",
            );
            icct_nms_input(
                "Short Name",
                "short_name",
                $values["short_name"],
                "text",
                'maxlength="8" data-auto-short="' .
                    ($shortNameAuto ? "1" : "0") .
                    '"',
            );
            icct_nms_input(
                "Hostname/IP Address",
                "hostname",
                $values["hostname"],
                "text",
                "required",
            );
            $categories = [0 => "Unclassified"];
            $segmentTypes = [0 => ""];
            foreach (
                db_fetch_assoc(
                    "SELECT id,name FROM plugin_icct_nms_categories ORDER BY sort_order,name",
                )
                as $c
            ) {
                $categories[$c["id"]] = $c["name"];
                $segmentTypes[$c["id"]] = icct_backend_category_device_type(
                    $c["id"],
                    $id,
                );
            }
            icct_nms_select(
                "Segment",
                "category_id",
                $categories,
                $values["category_id"],
            );
            $typeProfiles=icct_nms_device_types();
            $typeChoices=[''=>'None'];
            foreach ($typeProfiles as $profile) if ((int)$profile['category_id']===(int)$values['category_id']) $typeChoices[$profile['name']]=$profile['name'];
            icct_nms_select('Device Type','device_type',$typeChoices,$values['device_type']);
            ?>
            <script type="application/json" id="device-type-profiles"><?= json_encode(array_map(static function($p) { return ['name'=>$p['name'],'category_id'=>$p['category_id'],'physical_ports'=>$p['physical_ports'],'shape'=>icct_nms_type_shape($p)]; },array_values($typeProfiles)),JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?></script>
            <?php
            icct_nms_core_select(
                "Device Site Location",
                "site_id",
                $values["site_id"],
            );
            $racks = [0 => "Unassigned"];
            $rackData = icct_nms_device_rack_choices($id);
            foreach ($rackData as $r) {
                $racks[$r["id"]] = $r["name"];
            }
            icct_nms_select("Rack Name", "rack_id", $racks, $values["rack_id"]);
            icct_nms_input('Rack Unit Count (U)', 'rack_unit_count', $values['rack_unit_count'], 'number', 'min="1" max="42" required');

            $selectedRackRecord = null;
            foreach ($rackData as $r) {
                if ((int)$r['id'] === (int)$values['rack_id']) {
                    $selectedRackRecord = $r;
                    break;
                }
            }
            $positionParts = explode(':', (string)$values['rack_position']);
            $startUnit = count($positionParts) === 2 ? (int)$positionParts[0] : 0;
            $unitHeight = count($positionParts) === 2 ? (int)$positionParts[1] : 0;
            $isPeripheral = ($values['rack_position'] === 'peripheral');

            $summaryText = 'Select units';
            if ($isPeripheral) {
                $summaryText = 'Peripheral slot';
            } elseif ($startUnit > 0 && $unitHeight > 0) {
                $unitLabels = [];
                for ($u = $startUnit; $u < $startUnit + $unitHeight; $u++) {
                    $unitLabels[] = $u . 'U';
                }
                $summaryText = implode(', ', $unitLabels);
            }
            ?>
            <label class="field rack-unit-field"><span class="field-label">Placement in the Rack</span>
            <details id="rack-unit-picker"><summary><?= icct_nms_h($summaryText) ?></summary><div class="rack-unit-options"><?php
            if ($selectedRackRecord):
                $occupied = array_flip($selectedRackRecord['occupied'] ?? []);
                for ($unit = 1; $unit <= (int)$selectedRackRecord['unit_count']; $unit++):
                    $isOccupied = isset($occupied[$unit]);
                    $isChecked = $startUnit > 0 && $unit >= $startUnit && $unit < ($startUnit + $unitHeight);
                    $labelText = $unit . 'U' . ($isOccupied ? ' — In use' : '');
            ?><label class="<?= $isOccupied ? 'occupied' : '' ?>"><input type="checkbox" name="rack_units[]" value="<?= $unit ?>" <?= $isChecked ? 'checked' : '' ?> <?= $isOccupied ? 'disabled' : '' ?> aria-label="<?= icct_nms_h($labelText) ?>"><?= icct_nms_h($labelText) ?></label><?php
                endfor;
            ?><label><input type="checkbox" name="rack_peripheral" value="peripheral" <?= $isPeripheral ? 'checked' : '' ?> aria-label="Peripheral slot">Peripheral slot</label><?php
            else:
            ?><p class="rack-empty-notice">Select a Rack Name above to view and assign rack units.</p><?php
            endif;
            ?></div></details>
            <input type="hidden" name="rack_position" value="<?= icct_nms_h($values['rack_position']) ?>">
            <input type="hidden" name="rack_units[]" value="" disabled id="rack-empty-units">
            </label>
            <?php
            icct_nms_input(
                "MAC Address",
                "mac_address",
                $values["mac_address"],
                "text",
                'data-identity-auto="' .
                    (empty($meta["mac_address"]) &&
                    !empty($observedIdentity["mac_address"])
                        ? "1"
                        : "0") .
                    '"',
            );
            icct_nms_input(
                "Serial Number",
                "serial_number",
                $values["serial_number"],
                "text",
                'data-identity-auto="' .
                    (empty($meta["serial_number"]) &&
                    !empty($observedIdentity["serial_number"])
                        ? "1"
                        : "0") .
                    '"',
            );
            icct_nms_input(
                "Chassis ID",
                "chassis_id",
                $values["chassis_id"],
                "text",
                'data-identity-auto="' .
                    (empty($meta["chassis_id"]) &&
                    !empty($observedIdentity["chassis_id"])
                        ? "1"
                        : "0") .
                    '"',
            );
            icct_nms_core_select(
                "Device Template",
                "host_template_id",
                $values["host_template_id"],
            );
            icct_nms_core_select(
                "Poller Association",
                "poller_id",
                $values["poller_id"],
            );
            icct_nms_core_select(
                "No. of Collection Threads",
                "device_threads",
                $values["device_threads"],
            );
            icct_nms_input(
                "Cross Launch URL",
                "cross_launch_url",
                $values["cross_launch_url"],
                "url",
            );
            ?>
        </div>
        <label class="field notes">
            <span class="notes-heading">
                <span class="field-label">Notes/Description</span>
                <span id="notes-count"></span>
            </span>
            <textarea name="notes" maxlength="<?= max(
                148,
                mb_strlen((string) $values["notes"]),
            ) ?>"><?= icct_nms_h($values["notes"]) ?></textarea>
        </label>
    </fieldset>
    <?php if (!$readonly && empty($wizard)): ?>
    <footer class="form-footer">
        <!-- Basic Information is the first step; Next validates and saves before advancing. -->
        <button class="button previous" type="button" disabled aria-label="Previous step">Previous ←</button>
        <button class="button next" type="submit" aria-label="<?= !empty(
            $cloneId
        )
            ? "Create Clone"
            : "Next step" ?>"><?= !empty($cloneId)
    ? "Create Clone"
    : "Next →" ?></button>
    </footer>
    <?php endif; ?>
</form>
<script type="application/json" id="rack-data">
    <?= json_encode(
        $rackData,
        JSON_HEX_TAG |
            JSON_HEX_AMP |
            JSON_HEX_APOS |
            JSON_HEX_QUOT |
            JSON_THROW_ON_ERROR,
    ) ?>
</script>

<script type="application/json" id="segment-data">
    <?= json_encode(
        $segmentTypes,
        JSON_HEX_TAG |
            JSON_HEX_AMP |
            JSON_HEX_APOS |
            JSON_HEX_QUOT |
            JSON_THROW_ON_ERROR,
    ) ?>
</script>

<script type="application/json" id="identity-endpoint">
    <?= json_encode(
        $old["hostname"] ?? "",
        JSON_HEX_TAG |
            JSON_HEX_AMP |
            JSON_HEX_APOS |
            JSON_HEX_QUOT |
            JSON_THROW_ON_ERROR,
    ) ?>
</script>
