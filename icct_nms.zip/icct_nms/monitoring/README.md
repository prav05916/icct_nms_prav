# ICCT NMS — Monitoring Subsystem (NTP & NetFlow) & Backend Architecture

This document describes the complete architecture, data flow, daemon operation, and user interface for the **NTP** and **NetFlow** monitoring subsystems in the ICCT NMS Cacti plugin.

---

## 1. How the Backend Actually Works (Architecture & Flow)

The monitoring subsystem operates autonomously with **zero external dependencies** and is designed to run in air-gapped, offline environments such as **RHEL 9.4**.

### A. End-to-End NTP Flow

```
[User in Web UI: device.php#protocol]
               │
               ▼ Saves NTP Server & UDP Port
   [icct_nms_ntp_upsert()]
               │
               ├─────────────────────────────────────────────┐
               ▼                                             ▼
[Stores in plugin_icct_nms_ntp_devices]           [Instant Live Query: icct_nms_ntp_poll_device()]
                                                             │
                                                             ▼
                                               [48-byte UDP packet to Target:123]
                                                             │
                              ┌──────────────────────────────┴──────────────────────────────┐
                              ▼                                                             ▼
                     [Response Received (RFC 5905)]                                 [Timed Out / Unreachable]
                              │                                                             │
       Extract: Stratum, Leap, RefID, Timestamps (t1..t4)                 Check if 127.0.0.1 & chrony active
       Calculate: Offset (ms), Delay (ms), Jitter (ms)                                      │
                              │                                            ┌────────────────┴────────────────┐
                              ▼                                            ▼                                 ▼
               [Status: Synced or Degraded]                      [chronyc tracking data]           [Status: Unreachable]
                              │                                            │                                 │
                              └──────────────────────────────┬─────────────┘                                 │
                                                             ▼                                               ▼
                                            [INSERT / UPDATE into plugin_icct_nms_ntp_state]
                                                             ▲
                                                             │
                                   [Auto-Refresh on visiting ntp.php / Systemd 1-min timer]
```

#### Detailed NTP Processing Steps:
1. **Device Configuration & Immediate Poll**:
   - When the user configures NTP on a device and clicks **Save**, `icct_nms_ntp_upsert()` stores target parameters (`target_address`, `port`, `version`, thresholds).
   - Rather than storing static mock data, it **immediately triggers a live query** via `icct_nms_ntp_poll_device()`.
2. **RFC 5905 Live UDP Socket Engine**:
   - Opens a native UDP stream (`udp://<target>:<port>`) with a non-blocking timeout.
   - Assembles an RFC 5905 NTPv4 client request (48 bytes, `Mode 3`).
   - Computes high-precision timestamps:
     $$\text{Round-Trip Delay} = (t_4 - t_1) - (t_3 - t_2)$$
     $$\text{Clock Offset} = \frac{(t_2 - t_1) + (t_3 - t_4)}{2}$$
   - Converts offset and delay to milliseconds and evaluates thresholds (`maximum_offset_ms`, `maximum_jitter_ms`, `maximum_delay_ms`).
3. **Local Clock Integration (`chronyc`)**:
   - If the target is `127.0.0.1` or `localhost` on RHEL and direct UDP socket receives no response, the engine queries the local system clock state via `chronyc tracking` to extract real stratum and offset.
4. **Automated Refresh on Page Load**:
   - When any user visits `monitoring/controllers/ntp.php`, the controller automatically identifies devices whose data is missing or older than 60 seconds and polls them on-the-fly. Every device shows its own live, distinct status.
5. **Periodic Background Polling**:
   - The systemd timer `icct-nms-ntp-worker.timer` invokes `protocols/ntp/cli/ntp_worker.php --limit=500` every minute, maintaining fresh telemetry in `plugin_icct_nms_ntp_state`.

---

### B. End-to-End NetFlow / IPFIX Flow

```
[Network Routers / Switches / Linux Exporters]
                     │
                     ▼ NetFlow v5 / v9 / IPFIX UDP packets (Port 2055 / 9995)
   [icct-nms-netflow-collector daemon (protocols/netflow/cli/netflow_worker.php)]
                     │
                     ├─────────────────────────────────────────────────┐
                     ▼                                                 ▼
      [Decodes Packet Headers & Flow Records]             [Extracts Sender IP Address]
                     │                                                 │
                     ▼                                                 ▼
      [Calculates Bytes, Packets, Rates]                  [Matches host in plugin_icct_nms_netflow_devices]
                     │                                                 │
                     └───────────────────────────────┬─────────────────┘
                                                     ▼
                            [Records Top Talkers into plugin_icct_nms_netflow_top_talkers]
                            [Updates Real Status & Counters in plugin_icct_nms_netflow_state]
                                                     ▲
                                                     │
                             [Auto-Sampling on visiting netflow.php / Systemd timer]
```

#### Detailed NetFlow Processing Steps:
1. **Built-in Pure-PHP NetFlow Collector Daemon**:
   - `protocols/netflow/cli/netflow_worker.php --daemon --port=2055` binds to UDP port `2055` (and/or `9995`).
   - Operates with **zero external dependencies** — does not require `nfdump` or `nfcapd` to be installed.
   - Listens continuously for UDP datagrams, decodes NetFlow v5, v9, and IPFIX headers, extracts flow records (`src_ip`, `dst_ip`, `proto`, `src_port`, `dst_port`, `bytes`, `packets`), and records them directly into the Cacti database.
2. **Device State & Top Talker Aggregation**:
   - Incoming flows are mapped by exporter IP to the matching Cacti device.
   - Aggregated into `plugin_icct_nms_netflow_state` (Total Bytes, Total Packets, Active Flows, Top Talker JSON) and `plugin_icct_nms_netflow_top_talkers`.
3. **Graceful Awaiting Flow State**:
   - When a device is first added or before flows have arrived, the system sets `status = 'listening'` ("Awaiting flow export on UDP 2055") rather than showing dummy fake data.
   - For local loopback (`127.0.0.1`), it inspects live host interface counters and socket endpoints so local activity is reflected accurately.
4. **Automated Refresh on Page Load**:
   - Visiting `monitoring/controllers/netflow.php` immediately samples all enabled exporters so live traffic statistics and status badges are rendered without delay.

---

## 2. How the User Can See Everything in the UI

### 1. Configure NTP & NetFlow on a Device
1. Open the Device Wizard:
   `http://localhost/cacti/plugins/icct_nms/inventory/controllers/device.php?id=1`
2. Click **Protocol Config** (Step 2/7) or click the in-page anchor `#protocol`.
3. **Under NTP**:
   - Expand the **NTP (Network Time Protocol)** accordion.
   - Enter your NTP Server IP/hostname (e.g. `127.0.0.1` or `172.195.121.193` or upstream IP).
   - Port defaults to `123`, Version to `NTPv4`, Timeout to `3` seconds.
   - Click **Save**. The poller instantly verifies the server and renders a live status callout.
4. **Under NetFlow**:
   - Expand the **NetFlow** accordion.
   - Enter your Flow Exporter IP (e.g. `127.0.0.1` or router IP).
   - Set Collector Port (default `2055` or `9995`).
   - Click **Save**.

---

### 2. View NTP Monitoring in the UI
1. In the Cacti navigation sidebar under **ICCT NMS**, click **NTP Monitoring**.
   - Direct URL: `http://localhost/cacti/plugins/icct_nms/monitoring/controllers/ntp.php`
2. **Features**:
   - **Automatic Refresh**: The page queries every enabled device live upon opening.
   - **Real Metrics per Device**:
     - **Stratum**: Colour-coded badge (Green = Stratum 1–2, Yellow = Stratum 3–5, Orange = Stratum > 5).
     - **Offset (ms)**: Real measured clock offset (Green < 1ms, Yellow < 10ms, Red > 10ms).
     - **Jitter & Delay (ms)**: Measured network round-trip and dispersion times.
     - **Status Badge**: `Good` (synced), `Degraded` (threshold exceeded), `Unreachable` (timed out), or `Unsynced`.
   - **Device Drill-Down**: Click any device name to open its read-only details tab (`#view-ntp`) with the full peer association table.

---

### 3. View NetFlow Monitoring in the UI
1. In the Cacti navigation sidebar under **ICCT NMS**, click **NetFlow Monitoring**.
   - Direct URL: `http://localhost/cacti/plugins/icct_nms/monitoring/controllers/netflow.php`
2. **Features**:
   - **Automatic Refresh**: Live flow data is calculated and aggregated on load.
   - **Real Metrics per Device**:
     - **Active Flows**: Number of active flow cache entries.
     - **Flows/s & Throughput**: Real-time bandwidth rate (KB/s, MB/s, GB/s).
     - **Top Talker**: Top IP and byte count transferred.
     - **Status Badge**: `Active` (flows arriving / live traffic), `Listening` (waiting for flow datagrams on UDP port).
   - **Device Drill-Down**: Click any device to view the **Top Talkers** breakdown table (`#view-netflow`) with source IP, destination IP, protocol, ports, bytes, and packets.

---

## 3. Directory Layout & Key Files

```
plugins/icct_nms/
├── monitoring/
│   ├── controllers/
│   │   ├── ntp.php                 # Global NTP overview controller (triggers auto-refresh)
│   │   └── netflow.php             # Global NetFlow overview controller (triggers auto-refresh)
│   ├── services/
│   │   ├── ntp_service.php         # RFC 5905 live UDP poller engine & chrony reader
│   │   └── netflow_service.php     # NetFlow data access, rate calculations & interface sampler
│   ├── templates/
│   │   ├── ntp_view.php            # NTP overview table with live badges and instant search
│   │   ├── netflow_view.php        # NetFlow overview table with flow throughput & status
│   │   ├── device_view_ntp.php     # Per-device NTP summary & peer association table
│   │   └── device_view_netflow.php # Per-device NetFlow summary & top talkers table
│   └── README.md                   # This architecture documentation
├── protocols/
│   ├── ntp/
│   │   ├── cli/ntp_worker.php      # CLI worker for cron / systemd timer (outputs {"polled":N...})
│   │   ├── rhel/
│   │   │   ├── install_ntp_rhel.sh # RHEL 9.4 systemd installer for NTP timer
│   │   │   ├── diagnose_ntp_rhel.sh# Diagnostics script for RHEL 9.4
│   │   │   ├── icct-nms-ntp-worker.service.in
│   │   │   ├── icct-nms-ntp-worker.timer
│   │   │   └── ntp_test_server.py  # Offline Python UDP NTP lab test responder
│   │   └── templates/ntp.php       # NTP device protocol configuration form
│   └── netflow/
│       ├── cli/netflow_worker.php  # Native PHP UDP NetFlow collector daemon (port 2055)
│       ├── rhel/
│       │   ├── install_netflow_rhel.sh # RHEL 9.4 systemd installer for collector daemon
│       │   ├── diagnose_netflow_rhel.sh# NetFlow diagnostics script
│       │   ├── icct-nms-netflow-collector.service.in
│       │   ├── icct-nms-netflow-worker.service.in
│       │   └── icct-nms-netflow-worker.timer
│       └── templates/netflow.php   # NetFlow device protocol configuration form
└── SYSTEM_SETUP_RHEL.md            # Standalone RHEL 9.4 offline setup and terminal resolution guide
```

---

## 4. Running Unit Tests

All unit tests use standalone PHP stubs with zero external dependencies and run 100% offline:

```bash
php shared/tests/ntp_service_test.php
php shared/tests/netflow_service_test.php
php shared/tests/device_view_placement_test.php
php shared/tests/rack_unit_count_test.php
php shared/tests/rack_placement_test.php
```
