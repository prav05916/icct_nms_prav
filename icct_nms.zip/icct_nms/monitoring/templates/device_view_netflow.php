<?php
/**
 * Per-device NetFlow tab panel — included by device_view.php.
 * Expects $id (int) to be set by the parent template.
 */
require_once dirname(__DIR__) . '/services/netflow_service.php';
$netflowStatus  = icct_nms_netflow_status($id);
$netflowTalkers = icct_nms_netflow_top_talkers($id);

$nfDisplay = static function($value) { return icct_nms_h(trim((string)$value) !== '' ? $value : '—'); };
?>
<section id="view-netflow" data-device-view-panel="netflow" hidden>
    <h2>NetFlow</h2>
<?php if ($netflowStatus): ?>
    <section class="device-view-section">
        <h3>NetFlow Summary</h3>
        <dl class="device-detail-grid">
            <div><dt>Exporter IP</dt><dd><?= $nfDisplay($netflowStatus['exporter_ip']) ?></dd></div>
            <div><dt>Collector IP:Port</dt><dd><?= icct_nms_h($netflowStatus['collector_ip']) ?>:<?= (int)$netflowStatus['collector_port'] ?></dd></div>
            <div><dt>Flow Version</dt><dd><?= $netflowStatus['flow_version'] !== null ? 'v' . (int)$netflowStatus['flow_version'] : '—' ?></dd></div>
            <div><dt>Active Flows</dt><dd><?= icct_nms_h(number_format((int)$netflowStatus['active_flows'])) ?></dd></div>
            <div><dt>Flows/s</dt><dd><?= $netflowStatus['flows_per_second'] !== null ? icct_nms_h(number_format((float)$netflowStatus['flows_per_second'], 1)) : '—' ?></dd></div>
            <div><dt>Throughput</dt><dd><?= $netflowStatus['bytes_per_second'] !== null ? icct_nms_h(icct_nms_netflow_bytes_human((int)$netflowStatus['bytes_per_second'])) . '/s' : '—' ?></dd></div>
            <div><dt>Top Talker</dt><dd><?= $nfDisplay($netflowStatus['top_talker_ip']) ?><?= $netflowStatus['top_talker_bytes'] !== null ? ' (' . icct_nms_h(icct_nms_netflow_bytes_human((int)$netflowStatus['top_talker_bytes'])) . ')' : '' ?></dd></div>
            <div><dt>Last Polled</dt><dd><?= $nfDisplay($netflowStatus['last_polled'] ?? '') ?></dd></div>
        </dl>
    </section>
    <section class="device-view-section">
        <h3>Top Talkers</h3>
<?php if ($netflowTalkers): ?>
        <div class="site-table-wrap">
        <table class="site-table">
            <thead>
                <tr>
                    <th>Src IP</th>
                    <th>Dst IP</th>
                    <th>Protocol</th>
                    <th>Src Port</th>
                    <th>Dst Port</th>
                    <th>Bytes</th>
                    <th>Packets</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($netflowTalkers as $talker): ?>
            <tr>
                <td><?= icct_nms_h($talker['src_ip']) ?></td>
                <td><?= icct_nms_h($talker['dst_ip']) ?></td>
                <td><?= icct_nms_h($talker['protocol']) ?></td>
                <td><?= $talker['src_port'] !== null ? (int)$talker['src_port'] : '—' ?></td>
                <td><?= $talker['dst_port'] !== null ? (int)$talker['dst_port'] : '—' ?></td>
                <td><?= icct_nms_h(icct_nms_netflow_bytes_human((int)$talker['bytes'])) ?></td>
                <td><?= icct_nms_h(number_format((int)$talker['packets'])) ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
<?php else: ?>
        <p>No top-talker records available for this device.</p>
<?php endif; ?>
    </section>
<?php else: ?>
    <p>No NetFlow data available for this device. Ensure the NetFlow poller has run and collected data.</p>
<?php endif; ?>
</section>
