<?php
/**
 * NetFlow Monitoring overview template — lists all NetFlow-monitored devices.
 * Data: $netflowDevices (array from icct_nms_netflow_all())
 */
?>
<div class="titlebar">
    <h1><?= icct_nms_h($title) ?></h1>
</div>

<div class="site-table-controls">
    <label class="site-table-search-label" for="netflow-search">
        <span class="sr-only">Filter devices</span>
        <input type="search" id="netflow-search" class="site-table-search" placeholder="Filter devices…" aria-label="Filter NetFlow devices">
    </label>
    <span class="site-table-count" id="netflow-count">
        <?= count($netflowDevices) ?> device<?= count($netflowDevices) !== 1 ? 's' : '' ?>
    </span>
</div>

<div class="site-table-wrap">
<?php if ($netflowDevices): ?>
<table class="site-table" id="netflow-table">
    <thead>
        <tr>
            <th>Device</th>
            <th>Exporter IP</th>
            <th>Collector IP:Port</th>
            <th>Flow Version</th>
            <th>Active Flows</th>
            <th>Flows/s</th>
            <th>Throughput</th>
            <th>Top Talker</th>
            <th>Status</th>
            <th>Last Polled</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($netflowDevices as $row):
        $fps        = isset($row['flows_per_second']) ? (float)$row['flows_per_second'] : null;
        $bps        = isset($row['bytes_per_second']) ? (int)$row['bytes_per_second']   : null;
        $talkerBytes = isset($row['top_talker_bytes']) ? (int)$row['top_talker_bytes']  : null;
        $st         = $row['status'] ?? 'listening';
        $stBadge    = $st === 'active' ? 'badge-green' : ($st === 'listening' ? 'badge-yellow' : 'badge-grey');
        $stLabel    = ucfirst($st);
    ?>
    <tr data-filter-text="<?= icct_nms_h(strtolower($row['description'] . ' ' . $row['hostname'] . ' ' . $row['exporter_ip'])) ?>">
        <td><a href="inventory/controllers/device.php?id=<?= (int)$row['host_id'] ?>&amp;view=1#view-netflow"><?= icct_nms_h($row['description']) ?></a></td>
        <td><?= icct_nms_h($row['exporter_ip']) ?></td>
        <td><?= icct_nms_h($row['collector_ip']) ?>:<?= (int)$row['collector_port'] ?></td>
        <td><?= $row['flow_version'] !== null ? 'v' . (int)$row['flow_version'] : '—' ?></td>
        <td><?= icct_nms_h(number_format((int)$row['active_flows'])) ?></td>
        <td><?= $fps !== null ? icct_nms_h(number_format($fps, 1)) : '—' ?></td>
        <td><?= $bps !== null ? icct_nms_h(icct_nms_netflow_bytes_human($bps)) . '/s' : '—' ?></td>
        <td>
            <?php if ($row['top_talker_ip'] !== ''): ?>
                <?= icct_nms_h($row['top_talker_ip']) ?>
                <?= $talkerBytes !== null ? '(' . icct_nms_h(icct_nms_netflow_bytes_human($talkerBytes)) . ')' : '' ?>
            <?php else: ?>—<?php endif; ?>
        </td>
        <td><span class="badge <?= $stBadge ?>"><?= icct_nms_h($stLabel) ?></span></td>
        <td><?= icct_nms_h($row['last_polled'] ?? '—') ?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php else: ?>
<p class="site-table-empty">No NetFlow exporters found. Configure the NetFlow poller to populate this view.</p>
<?php endif; ?>
</div>

<script>
(function () {
    var input = document.getElementById('netflow-search');
    var count = document.getElementById('netflow-count');
    var table = document.getElementById('netflow-table');
    if (!input || !table) return;
    input.addEventListener('input', function () {
        var q = input.value.toLowerCase();
        var rows = table.querySelectorAll('tbody tr');
        var visible = 0;
        rows.forEach(function (row) {
            var text = (row.dataset.filterText || '');
            var show = !q || text.includes(q);
            row.hidden = !show;
            if (show) visible++;
        });
        if (count) count.textContent = visible + ' device' + (visible !== 1 ? 's' : '');
    });
}());
</script>
