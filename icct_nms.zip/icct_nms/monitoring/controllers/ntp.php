<?php
/**
 * NTP Monitoring overview — shows NTP status for all monitored devices.
 */
require dirname(__DIR__, 2) . '/../../include/auth.php';
require_once dirname(__DIR__, 2) . '/shared/services/bootstrap.php';
require_once dirname(__DIR__, 2) . '/monitoring/services/ntp_service.php';

try {
    icct_nms_backend();
    $title = 'NTP Monitoring';
    require dirname(__DIR__, 2) . '/shared/templates/header.php';
    $ntpDevices = icct_nms_ntp_all();
    require dirname(__DIR__, 2) . '/monitoring/templates/ntp_view.php';
    require dirname(__DIR__, 2) . '/shared/templates/footer.php';
} catch (Throwable $e) {
    icct_nms_failure($e);
}
