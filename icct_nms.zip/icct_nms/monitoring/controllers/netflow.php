<?php
/**
 * NetFlow Monitoring overview — shows NetFlow stats for all exporters.
 */
require dirname(__DIR__, 2) . '/../../include/auth.php';
require_once dirname(__DIR__, 2) . '/shared/services/bootstrap.php';
require_once dirname(__DIR__, 2) . '/monitoring/services/netflow_service.php';

try {
    icct_nms_backend();
    $title = 'NetFlow Monitoring';
    require dirname(__DIR__, 2) . '/shared/templates/header.php';
    $netflowDevices = icct_nms_netflow_all();
    require dirname(__DIR__, 2) . '/monitoring/templates/netflow_view.php';
    require dirname(__DIR__, 2) . '/shared/templates/footer.php';
} catch (Throwable $e) {
    icct_nms_failure($e);
}
