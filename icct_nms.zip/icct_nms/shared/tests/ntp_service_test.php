<?php
/**
 * NTP service unit tests — pure PHP stubs, no framework, no network.
 */
$ntpDevices = [];
$ntpPeers   = [];
$ntpState   = [];

function db_fetch_row_prepared($sql, $args) {
    $id = (int)$args[0];
    if (!isset($GLOBALS['ntpDevices'][$id]) && !isset($GLOBALS['ntpState'][$id])) {
        return [];
    }
    return array_merge(
        $GLOBALS['ntpDevices'][$id] ?? [],
        $GLOBALS['ntpState'][$id] ?? []
    );
}

function db_fetch_cell_prepared($sql, $args) {
    return 0;
}

function db_fetch_assoc_prepared($sql, $args) {
    return array_values(array_filter($GLOBALS['ntpPeers'], fn($r) => ($r['host_id'] ?? 0) === (int)$args[0]));
}

function db_fetch_assoc($sql) {
    $rows = [];
    foreach ($GLOBALS['ntpDevices'] as $id => $dev) {
        $rows[] = array_merge($dev, $GLOBALS['ntpState'][$id] ?? []);
    }
    return $rows;
}

function icct_backend_category_execute($sql, $args = []) {
    if (str_contains($sql, 'INSERT INTO plugin_icct_nms_ntp_devices')) {
        $GLOBALS['ntpDevices'][$args[0]] = [
            'host_id'        => $args[0],
            'enabled'        => 1,
            'target_address' => $args[1],
            'port'           => $args[2],
            'version'        => $args[3],
            'timeout_seconds'=> $args[4],
            'poll_interval'  => $args[5],
            'maximum_offset_ms' => $args[6],
            'maximum_jitter_ms' => $args[7],
            'maximum_delay_ms'  => $args[8],
            'expected_source'   => $args[9],
        ];
    }
    if (str_contains($sql, 'INSERT INTO plugin_icct_nms_ntp_state')) {
        if (str_contains($sql, '"unreachable"')) {
            $GLOBALS['ntpState'][$args[0]] = [
                'host_id'         => $args[0],
                'status'          => 'unreachable',
                'reachable'       => 0,
                'synchronized'    => 0,
                'selected_source' => $args[1],
                'stratum'         => 16,
                'reference_id'    => 'NONE',
                'offset_ms'       => null,
                'jitter_ms'       => null,
                'delay_ms'        => null,
                'last_error'      => $args[2] ?? '',
            ];
        } else {
            $GLOBALS['ntpState'][$args[0]] = [
                'host_id'         => $args[0],
                'status'          => $args[1],
                'reachable'       => 1,
                'synchronized'    => $args[2],
                'selected_source' => $args[3],
                'stratum'         => $args[4],
                'reference_id'    => $args[6],
                'offset_ms'       => $args[7],
                'jitter_ms'       => $args[8],
                'delay_ms'        => $args[9],
            ];
        }
    }
    if (str_contains($sql, 'DELETE FROM plugin_icct_nms_ntp_peers')) {
        $GLOBALS['ntpPeers'] = array_values(
            array_filter($GLOBALS['ntpPeers'], fn($r) => ($r['host_id'] ?? 0) !== (int)$args[0])
        );
    }
    if (str_contains($sql, 'INSERT INTO plugin_icct_nms_ntp_peers')) {
        $GLOBALS['ntpPeers'][] = [
            'host_id'  => $args[0],
            'peer_ip'  => $args[1],
            'peer_name'=> $args[2],
            'stratum'  => $args[3],
            'offset_ms'=> $args[4],
            'delay_ms' => $args[5],
            'jitter_ms'=> $args[6],
            'reachable'=> $args[7] ?? 1,
            'selected' => $args[8] ?? 1,
        ];
    }
}

require __DIR__ . '/../../monitoring/services/ntp_service.php';

// Test 1: empty result when no data
$result = icct_nms_ntp_status(1, false);
assert($result === [], 'Empty status when no data');

// Test 2: upsert stores data
icct_nms_ntp_upsert(1, ['ntp_server' => '192.168.1.1', 'timeout_seconds' => 1]);
$result = icct_nms_ntp_status(1, false);
assert(($result['ntp_server'] ?? '') === '192.168.1.1', 'NTP server stored');
assert(($result['target_address'] ?? '') === '192.168.1.1', 'Target address alias stored');

// Test 3: peer deletion
icct_nms_ntp_peers_upsert(1, []);
$peers = icct_nms_ntp_peers(1);
assert($peers === [], 'Peers cleared after empty upsert');

// Test 3b: peer insert then read back
icct_nms_ntp_peers_upsert(1, [
    ['peer_ip' => '10.0.0.1', 'peer_name' => 'ntp1', 'stratum' => 1, 'reachable' => true, 'selected' => true],
]);
$peers = icct_nms_ntp_peers(1);
assert(count($peers) === 1, 'One peer inserted');
assert(($peers[0]['peer_ip'] ?? '') === '10.0.0.1', 'Peer IP correct');

// Test 3c: clearing peers removes them
icct_nms_ntp_peers_upsert(1, []);
$peers = icct_nms_ntp_peers(1);
assert($peers === [], 'Peers cleared after second empty upsert');

// Test 4: ntp_all returns all rows without refresh
$ntpDevices = [];
$ntpState = [];
icct_nms_ntp_upsert(2, ['ntp_server' => '10.0.0.1', 'timeout_seconds' => 1]);
icct_nms_ntp_upsert(3, ['ntp_server' => '10.0.0.2', 'timeout_seconds' => 1]);
$all = icct_nms_ntp_all(false);
assert(count($all) >= 2, 'ntp_all returns all stored rows');

// Test 5: Verify RFC 5905 NTP query function packet format
$res = icct_nms_ntp_query('127.0.0.1', 12345, 1);
assert($res['ok'] === false, 'Non-listening test port correctly times out');
assert(str_contains($res['error'], 'timed out') || str_contains($res['error'], 'failed'), 'Error message accurate');

echo "NTP service tests passed.\n";
