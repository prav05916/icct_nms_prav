<?php
/**
 * NetFlow service unit tests — pure PHP stubs, no framework, no network.
 */
$netflowDevices = [];
$netflowState   = [];
$talkers        = [];

function db_fetch_row_prepared($sql, $args) {
    $id = (int)$args[0];
    if (!isset($GLOBALS['netflowDevices'][$id]) && !isset($GLOBALS['netflowState'][$id])) {
        return [];
    }
    return array_merge(
        $GLOBALS['netflowDevices'][$id] ?? [],
        $GLOBALS['netflowState'][$id] ?? []
    );
}

function db_fetch_cell_prepared($sql, $args) {
    if (str_contains($sql, 'top_json')) {
        $id = (int)$args[0];
        return $GLOBALS['netflowState'][$id]['top_json'] ?? '[]';
    }
    return 0;
}

function db_fetch_assoc_prepared($sql, $args) {
    if (str_contains($sql, 'top_talkers')) {
        $id = (int)$args[0];
        return array_values(array_filter($GLOBALS['talkers'], fn($t) => ($t['host_id'] ?? 0) === $id));
    }
    return [];
}

function db_fetch_assoc($sql) {
    $rows = [];
    foreach ($GLOBALS['netflowDevices'] as $id => $dev) {
        $rows[] = array_merge($dev, $GLOBALS['netflowState'][$id] ?? []);
    }
    return $rows;
}

function icct_backend_category_execute($sql, $args = []) {
    if (str_contains($sql, 'INSERT INTO plugin_icct_nms_netflow_devices')) {
        $GLOBALS['netflowDevices'][$args[0]] = [
            'host_id'          => $args[0],
            'enabled'          => 1,
            'exporter_address' => $args[1],
            'version'          => $args[2],
            'sampling_rate'    => $args[3],
            'active_timeout'   => $args[4],
            'inactive_timeout' => $args[5],
        ];
    }
    if (str_contains($sql, 'INSERT INTO plugin_icct_nms_netflow_state')) {
        $GLOBALS['netflowState'][$args[0]] = [
            'host_id'        => $args[0],
            'status'         => 'listening',
            'collector_path' => $args[1],
            'total_bytes'    => 0,
            'total_packets'  => 0,
            'total_flows'    => 0,
            'top_json'       => '[]',
        ];
    }
    if (str_contains($sql, 'UPDATE plugin_icct_nms_netflow_state')) {
        $id = end($args);
        if (isset($GLOBALS['netflowState'][$id])) {
            if (count($args) >= 5) {
                $GLOBALS['netflowState'][$id]['status'] = 'active';
                $GLOBALS['netflowState'][$id]['total_bytes'] = (int)$args[0];
                $GLOBALS['netflowState'][$id]['total_packets'] = (int)$args[1];
                $GLOBALS['netflowState'][$id]['total_flows'] = (int)$args[2];
                $GLOBALS['netflowState'][$id]['top_json'] = (string)$args[3];
            }
        }
    }
    if (str_contains($sql, 'INSERT INTO plugin_icct_nms_netflow_top_talkers')) {
        $GLOBALS['talkers'][] = [
            'host_id'  => $args[0],
            'src_ip'   => $args[1],
            'dst_ip'   => $args[2] ?? '10.0.0.1',
            'protocol' => $args[3] ?? 'TCP',
            'src_port' => $args[4] ?? 80,
            'dst_port' => $args[5] ?? 443,
            'bytes'    => $args[6] ?? 0,
            'packets'  => $args[7] ?? 0,
        ];
    }
}

require __DIR__ . '/../../monitoring/services/netflow_service.php';

// Test 1: empty
assert(icct_nms_netflow_status(1, false) === [], 'Empty before insert');

// Test 2: upsert
icct_nms_netflow_upsert(1, ['exporter_ip' => '10.0.0.1', 'collector_ip' => '10.0.0.2', 'collector_port' => 2055]);
$r = icct_nms_netflow_status(1, false);
assert(($r['exporter_ip'] ?? '') === '10.0.0.1', 'Exporter IP stored');
assert(($r['collector_ip'] ?? '') === '10.0.0.2', 'Collector IP stored');
assert(($r['collector_port'] ?? 0) === 2055, 'Collector port stored');

// Test 3: bytes human readable
assert(icct_nms_netflow_bytes_human(1536) === '1.5 KB', 'Bytes human KB');
assert(icct_nms_netflow_bytes_human(1073741824) === '1 GB', 'Bytes human GB');

// Test 4: bytes_human for B (under 1024)
assert(icct_nms_netflow_bytes_human(512) === '512 B', 'Bytes human B');

// Test 5: top talkers insert & sampling
$talkers = [];
icct_nms_netflow_top_talkers_insert(1, [['src_ip' => '1.2.3.4', 'dst_ip' => '5.6.7.8', 'protocol' => 'TCP', 'bytes' => 2048, 'packets' => 10]]);
$t = icct_nms_netflow_top_talkers(1);
assert(count($t) >= 1, 'Top talkers inserted');
assert(($t[0]['src_ip'] ?? '') === '1.2.3.4', 'Top talker src_ip correct');

// Sampling updates state from live talkers
$res = icct_nms_netflow_sample_device(1);
assert($res['ok'] === true, 'Sample device succeeded');
assert($res['status'] === 'active', 'State became active after flows detected');
assert($res['total_bytes'] === 2048, 'Total bytes aggregated from talkers');

echo "NetFlow service tests passed.\n";
